package com.audio.transcribe;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/transcribe")
public class TranscriptionController {

    public TranscriptionController() {
    }

    @PostMapping
    public ResponseEntity<String> transcribeAudio(@RequestParam("file") MultipartFile file) {
        File tempFile = null;
        try {
            // Save uploaded file to temp location with proper name
            String extension = getFileExtension(file.getOriginalFilename());
            String tempFileName = "audio_transcribe_" + System.currentTimeMillis() + extension;
            File tempDir = new File(System.getProperty("java.io.tmpdir"));
            tempFile = new File(tempDir, tempFileName);
            
            System.out.println("[API] Saving file to: " + tempFile.getAbsolutePath());
            file.transferTo(tempFile);
            System.out.println("[API] File saved, size: " + tempFile.length() + " bytes");

            // Call Whisper CLI to transcribe
            String transcript = transcribeWithWhisper(tempFile);
            
            if (transcript.isBlank()) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("No transcription text returned. Make sure whisper is installed: pip install openai-whisper");
            }
            return ResponseEntity.ok(transcript.trim());
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing audio file: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error during transcription: " + e.getMessage());
        } finally {
            if (tempFile != null && tempFile.exists()) {
                if (tempFile.delete()) {
                    System.out.println("[API] Temp file deleted");
                }
            }
        }
    }

    private String getFileExtension(String filename) {
        if (filename == null) return ".mp3";
        int lastDot = filename.lastIndexOf('.');
        return (lastDot > 0) ? filename.substring(lastDot) : ".mp3";
    }

    private String transcribeWithWhisper(File audioFile) throws Exception {
        List<String> command = new ArrayList<>();
        String pythonExe = "C:\\Program Files\\Python312\\python.exe";
        File pythonFile = new File(pythonExe);
        if (!pythonFile.exists()) {
            pythonExe = "python";
        }
        
        String tmpDir = System.getProperty("java.io.tmpdir");
        String audioPath = audioFile.getAbsolutePath();
        String baseName = audioFile.getName();
        if (baseName.contains(".")) {
            baseName = baseName.substring(0, baseName.lastIndexOf('.'));
        }
        String expectedTranscriptPath = new File(tmpDir, baseName + ".txt").getAbsolutePath();
        
        System.out.println("\n[Whisper] ============ Starting Transcription ============");
        System.out.println("[Whisper] Python: " + pythonExe);
        System.out.println("[Whisper] Audio file: " + audioPath);
        System.out.println("[Whisper] File exists: " + audioFile.exists());
        System.out.println("[Whisper] File size: " + audioFile.length());
        System.out.println("[Whisper] Temp dir: " + tmpDir);
        System.out.println("[Whisper] Expected output: " + expectedTranscriptPath);
        
        // Build command - using tiny model for faster initial testing
        command.add(pythonExe);
        command.add("-m");
        command.add("whisper");
        command.add(audioPath);
        command.add("--model");
        command.add("tiny");  // Fast model for quick testing
        command.add("--output_format");
        command.add("txt");
        command.add("--output_dir");
        command.add(tmpDir);
        command.add("--fp16");
        command.add("False");

        System.out.println("[Whisper] Command: " + String.join(" ", command));
        System.out.println("[Whisper] ====================================");
        
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(new File(tmpDir));
        pb.redirectErrorStream(true);
        Process process = pb.start();
        
        // Capture output
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println("[Whisper] " + line);
            output.append(line).append("\n");
        }
        
        int exitCode = process.waitFor();
        System.out.println("[Whisper] Exit code: " + exitCode);
        
        if (exitCode != 0) {
            throw new RuntimeException("Whisper failed with exit code " + exitCode);
        }

        // Look for the transcript file
        File transcriptFile = new File(expectedTranscriptPath);
        System.out.println("[Whisper] Checking for: " + expectedTranscriptPath);
        System.out.println("[Whisper] File exists: " + transcriptFile.exists());
        
        if (!transcriptFile.exists()) {
            // Try to find any .txt file in the directory
            System.out.println("[Whisper] Expected file not found, searching directory...");
            File tmpDirFile = new File(tmpDir);
            File[] files = tmpDirFile.listFiles((dir, name) -> 
                name.startsWith("audio_") && name.endsWith(".txt"));
            
            if (files != null && files.length > 0) {
                System.out.println("[Whisper] Found " + files.length + " matching files");
                for (File f : files) {
                    System.out.println("[Whisper]   - " + f.getName() + " (" + f.length() + " bytes)");
                }
                transcriptFile = files[0]; // Use first found
                System.out.println("[Whisper] Using file: " + transcriptFile.getAbsolutePath());
            } else {
                System.out.println("[Whisper] No matching files found!");
                System.out.println("[Whisper] Directory contents:");
                if (tmpDirFile.exists() && tmpDirFile.isDirectory()) {
                    File[] allFiles = tmpDirFile.listFiles();
                    if (allFiles != null) {
                        for (File f : allFiles) {
                            if (f.isFile() && (f.getName().contains("audio") || f.getName().endsWith(".txt"))) {
                                System.out.println("[Whisper]   - " + f.getName());
                            }
                        }
                    }
                }
                throw new RuntimeException("Transcript file not generated");
            }
        }
        
        String transcript = new String(Files.readAllBytes(transcriptFile.toPath())).trim();
        System.out.println("[Whisper] Transcript length: " + transcript.length());
        System.out.println("[Whisper] ============ Transcription Complete ============\n");
        
        transcriptFile.delete();
        
        return transcript;
    }

}


